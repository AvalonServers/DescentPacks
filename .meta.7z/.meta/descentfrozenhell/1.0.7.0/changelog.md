# Descent Frozen Hell 1.0.7.0

Property | old value | new value
---|---|---
Pack Version | `1.0.6.0` | `1.0.7.0`
Forge Version | `14.23.5.2836` | `14.23.5.2838`
Author | `CitadelCore` | `CitadelCore, Skye`


## Entries

### Updated Entries

updated `industrial-foregoing`

Property | old value | new value
---|---|---
Release Type | `BETA` | `RELEASE`



updated `journeymap`

Property | old value | new value
---|---|---
Version | `journeymap-1.12.2-5.5.5b5` | `journeymap-1.12.2-5.5.5b6`



updated `jei`

Property | old value | new value
---|---|---
Version | `jei_1.12.2-4.15.0.278.jar` | `jei_1.12.2-4.15.0.279.jar`



updated `sampler`

Property | old value | new value
---|---|---
Version | `sampler-1.83.jar` | `sampler-1.84.jar`



updated `tough-as-nails`

Property | old value | new value
---|---|---
Version | `ToughAsNails-1.12.2-3.1.0.140-universal.jar` | `ToughAsNails-1.12.2-3.1.0.141-universal.jar`



### Removed Entries

removed `stacksize`

Property | old value | new value
---|---|---
ID | `stacksize` | 
Version | `stacksize-1.12.2-1.0.jar` | 
Provider | `CURSE` | 
Side | `BOTH` | 
Optional | `false` | 
Release Type | `RELEASE` | 
Author | `wwrpg` | 






