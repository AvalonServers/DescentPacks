# Descent Frozen Hell 1.0.7.1

Property | old value | new value
---|---|---
Pack Version | `1.0.7.0` | `1.0.7.1`

No change in entries




