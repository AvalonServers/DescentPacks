# Descent Frozen Hell 1.1.1

Property | old value | new value
---|---|---
Pack Version | `1.1` | `1.1.1`


## Entries

### Added Entries

added `opencomputers-book-converter`

Property | old value | new value
---|---|---
ID |  | `opencomputers-book-converter`
Version |  | `ocbookconv-0.1.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `opencomputers`
Release Type |  | `Beta`
Author |  | `BrisingrAerowing`



### Updated Entries

updated `applied-energistics-2`

Property | old value | new value
---|---|---
Author | `akarso, AlgorithmX2, Cisien, fireball1725, thatsIch` | `akarso, AlgorithmX2, Cisien, FireBall1725, thatsIch`



updated `baubles`

Property | old value | new value
---|---|---
Author | `azanor` | `Azanor13`



updated `journeymap`

Property | old value | new value
---|---|---
Version | `journeymap-1.12.2-5.5.5b8.jar` | `journeymap-1.12.2-5.5.5b9.jar`



updated `thaumcraft`

Property | old value | new value
---|---|---
Author | `azanor` | `Azanor13`



updated `wearable-backpacks`

Property | old value | new value
---|---|---
Author | `asiekierka, InsomniaKitten, koppeh, PuppetzMedia` | `asiekierka, InsomniaKitten, PuppetzMedia, user-6837585`






