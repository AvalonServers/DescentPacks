# Descent Frozen Hell 1.1.2

Property | old value | new value
---|---|---
Pack Version | `1.1.1` | `1.1.2`


## Entries

### Updated Entries

updated `bwm-suite`

Property | old value | new value
---|---|---
Version | `BetterWithMods-1.12-2.3.20-1033.jar` | `BetterWithMods-1.12-2.3.20-1035.jar`



updated `jei`

Property | old value | new value
---|---|---
Version | `jei_1.12.2-4.15.0.285.jar` | `jei_1.12.2-4.15.0.287.jar`



### Removed Entries

removed `jecalculation`

Property | old value | new value
---|---|---
ID | `jecalculation` | 
Version | `jecalculation-1.12.2-3.0.0` | 
Provider | `DIRECT` | 
Side | `CLIENT` | 
Optional | `false` | 
Url | `https://launcher.towerdevs.xyz/store/jecalculation-1.12.2-3.0.0.jar` | 






