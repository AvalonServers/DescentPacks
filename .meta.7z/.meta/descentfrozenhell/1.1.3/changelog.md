# Descent Frozen Hell 1.1.3

Property | old value | new value
---|---|---
Pack Version | `1.1.2.2` | `1.1.3`
Author | `CitadelCore, Skye` | `CitadelCore, Skye, ThePiGuy24`


## Entries

### Added Entries

added `openprinter`

Property | old value | new value
---|---|---
ID |  | `openprinter`
Version |  | `OpenPrinter-1.12.2-0.1.0.7.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `opencomputers`
Release Type |  | `Release`
Author |  | `ben_mkiv, MichiyoRavencroft`






