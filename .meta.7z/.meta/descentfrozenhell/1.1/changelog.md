# Descent Frozen Hell 1.1

Property | old value | new value
---|---|---
Pack Version | `1.0.7.1` | `1.1`


## Entries

### Added Entries

added `bwm-core`

Property | old value | new value
---|---|---
ID |  | `bwm-core`
Version |  | `BetterWithLib-1.12-1.5.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Release Type |  | `Release`
Author |  | `primetoxinz`



added `bwm-suite`

Property | old value | new value
---|---|---
ID |  | `bwm-suite`
Version |  | `BetterWithMods-1.12-2.3.20-1033.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `bwm-core`
Release Type |  | `Beta`
Author |  | `BeetoGuy, primetoxinz`



added `cofh-core`

Property | old value | new value
---|---|---
ID |  | `cofh-core`
Version |  | `CoFHCore-1.12.2-4.6.3.27-universal.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `redstone-flux`
Release Type |  | `Release`
Author |  | `KingLemming, TeamCoFH`



added `extra-utilities`

Property | old value | new value
---|---|---
ID |  | `extra-utilities`
Version |  | `extrautils2-1.12-1.9.9.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Release Type |  | `Release`
Author |  | `RWTema`



added `thermal-expansion`

Property | old value | new value
---|---|---
ID |  | `thermal-expansion`
Version |  | `ThermalExpansion-1.12.2-5.5.4.43-universal.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `thermal-foundation`, `codechicken-lib-1-8`
Release Type |  | `Release`
Author |  | `KingLemming, TeamCoFH`



### Updated Entries

updated `applied-energistics-2`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `autoreglib`

Property | old value | new value
---|---|---
Version | `AutoRegLib-1.3-28.jar` | `AutoRegLib-1.3-31.jar`
Release Type | `RELEASE` | `Release`
Author | `Vazkii` | `Vazkii_`



updated `baubles`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `better-advancements`

Property | old value | new value
---|---|---
Version | `BetterAdvancements-1.12.2-0.1.0.77` | `BetterAdvancements-1.12.2-0.1.0.77.jar`
Release Type | `RELEASE` | `Release`



updated `better-builders-wands`

Property | old value | new value
---|---|---
Version | `Better Builder's Wands 0.13.2 [MC1.12; rev 271]` | `BetterBuildersWands-1.12.2-0.13.2.271+5997513.jar`
Release Type | `BETA` | `Beta`



updated `better-foliage`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `better-with-engineering`

Property | old value | new value
---|---|---
Required Dependencies | `better-with-mods` | `bwm-suite`
Release Type | `RELEASE` | `Release`



updated `catwalks-4`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `chameleon`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `charset-audio`

Property | old value | new value
---|---|---
Version | `Charset Audio 0.5.5.7` | `Charset-Audio-0.5.5.7.jar`
Release Type | `BETA` | `Beta`



updated `charset-block-carrying`

Property | old value | new value
---|---|---
Version | `Charset Tweak Carry 0.5.4.6` | `Charset-TweakCarry-0.5.4.6.jar`
Release Type | `RELEASE` | `Release`



updated `charset-immersion`

Property | old value | new value
---|---|---
Version | `Charset Immersion 0.5.5.7` | `Charset-Immersion-0.5.5.7.jar`
Release Type | `BETA` | `Beta`



updated `charset-lib`

Property | old value | new value
---|---|---
Version | `Charset Lib 0.5.5.7` | `Charset-Lib-0.5.5.7.jar`
Release Type | `RELEASE` | `Release`



updated `charset-storage-locks`

Property | old value | new value
---|---|---
Version | `Charset Storage Locks 0.5.2.0` | `Charset-StorageLocks-0.5.2.0.jar`
Release Type | `RELEASE` | `Release`



updated `charset-tablet`

Property | old value | new value
---|---|---
Version | `Charset Tablet 0.5.5.7` | `Charset-Tablet-0.5.5.7.jar`
Release Type | `BETA` | `Beta`



updated `charset-tools`

Property | old value | new value
---|---|---
Version | `Charset Tools Engineering 0.5.5.2` | `Charset-ToolsEngineering-0.5.5.2.jar`
Release Type | `BETA` | `Beta`



updated `charset-tweaks`

Property | old value | new value
---|---|---
Version | `Charset Tweaks 0.5.5.7` | `Charset-Tweaks-0.5.5.7.jar`
Release Type | `RELEASE` | `Release`



updated `charsetpatches`

Property | old value | new value
---|---|---
Version | `CharsetPatches 0.1.6` | `CharsetPatches-0.1.6.jar`
Release Type | `RELEASE` | `Release`



updated `chisel`

Property | old value | new value
---|---|---
Version | `Chisel - MC1.12.2-0.2.1.35` | `Chisel-MC1.12.2-0.2.1.35.jar`
Release Type | `BETA` | `Beta`



updated `chisels-bits`

Property | old value | new value
---|---|---
Version | `chiselsandbits-14.32.jar` | `chiselsandbits-14.33.jar`
Release Type | `RELEASE` | `Release`



updated `codechicken-lib-1-8`

Property | old value | new value
---|---|---
Version | `CodeChicken Lib 1.12.2-3.2.2.353-universal` | `CodeChickenLib-1.12.2-3.2.2.353-universal.jar`
Release Type | `RELEASE` | `Release`



updated `cofh-world`

Property | old value | new value
---|---|---
Version | `CoFHWorld-1.12.2-1.3.0.6-universal.jar` | `CoFHWorld-1.12.2-1.3.1.7-universal.jar`
Release Type | `RELEASE` | `Release`



updated `colytra`

Property | old value | new value
---|---|---
Version | `colytra-1.12.2-1.2.0.jar` | `colytra-1.12.2-1.2.0.1.jar`
Release Type | `RELEASE` | `Release`



updated `computronics`

Property | old value | new value
---|---|---
Version | `Computronics-1.12.1-1.6.5` | `Computronics-1.12.2-1.6.6`
Url | `http://files.vexatos.com/Computronics/Computronics-1.12.1-1.6.5.jar` | `http://files.vexatos.com/Computronics/Computronics-1.12.2-1.6.6.jar`



updated `ctm`

Property | old value | new value
---|---|---
Version | `CTM - MC1.12.2-0.3.3.22` | `CTM-MC1.12.2-0.3.3.22.jar`
Release Type | `BETA` | `Beta`



updated `crafttweaker`

Property | old value | new value
---|---|---
Version | `CraftTweaker2-1.12-4.1.17` | `CraftTweaker2-1.12-4.1.19.jar`
Release Type | `RELEASE` | `Release`
Author | `jaredlll08` | `Jaredlll08`



updated `dynamic-lights`

Property | old value | new value
---|---|---
Version | `Dynamic Lights` | `DynamicLights-1.12.2.jar`
Release Type | `RELEASE` | `Release`



updated `dynamic-surroundings`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `extracells2`

Property | old value | new value
---|---|---
Version | `ExtraCells-1.12.2-2.6.2` | `ExtraCells-1.12.2-2.6.2a.jar`
Release Type | `BETA` | `Beta`



updated `fancy-block-particles`

Property | old value | new value
---|---|---
Version | `FBP-2.4.1` | `FancyBlockParticles-1.12.x-2.4.1.jar`
Release Type | `RELEASE` | `Release`



updated `faster-ladder-climbing`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `foamfix-for-minecraft`

Property | old value | new value
---|---|---
Version | `FoamFix 0.10.5 (1.12.2)` | `foamfix-0.10.5-1.12.2.jar`
Release Type | `RELEASE` | `Release`



updated `forge-multipart-cbe`

Property | old value | new value
---|---|---
Version | `ForgeMultipart 1.12.2-2.6.1.81-universal` | `ForgeMultipart-1.12.2-2.6.1.81-universal.jar`
Release Type | `RELEASE` | `Release`



updated `gravestone-mod`

Property | old value | new value
---|---|---
Version | `[1.12.2] Gravestone Mod 1.10.2` | `gravestone-1.10.2.jar`
Release Type | `BETA` | `Beta`



updated `hardcore-darkness`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `hwyla`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `immersive-cables`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `immersive-engineering`

Property | old value | new value
---|---|---
Version | `Immersive Engineering 0.12 - 89` | `ImmersiveEngineering-0.12-89.jar`
Release Type | `RELEASE` | `Release`



updated `immersive-petroleum`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `immersive-tech`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `industrial-foregoing`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `industrial-wires`

Property | old value | new value
---|---|---
Version | `1.7-36 (MC 1.12.x)` | `IndustrialWires-1.7-36.jar`
Release Type | `RELEASE` | `Release`



updated `inventory-tweaks`

Property | old value | new value
---|---|---
Version | `Inventory Tweaks 1.64+dev.146` | `InventoryTweaks-1.64+dev.146.jar`
Release Type | `ALPHA` | `Alpha`



updated `journeymap`

Property | old value | new value
---|---|---
Version | `journeymap-1.12.2-5.5.5b6` | `journeymap-1.12.2-5.5.5b8.jar`
Release Type | `BETA` | `Beta`



updated `jei`

Property | old value | new value
---|---|---
Version | `jei_1.12.2-4.15.0.279.jar` | `jei_1.12.2-4.15.0.285.jar`
Release Type | `BETA` | `Beta`



updated `just-enough-resources-jer`

Property | old value | new value
---|---|---
Version | `JustEnoughResources-1.12.2-0.9.0.53` | `JustEnoughResources-1.12.2-0.9.2.60.jar`
Release Type | `ALPHA` | `Release`



updated `laggoggles`

Property | old value | new value
---|---|---
Version | `LagGoggles-FORGE-1.12.2-4.3-HOTFIX.jar` | `LagGoggles-FAT-1.12.2-4.6.jar`
Release Type | `RELEASE` | `Release`



updated `modtweaker`

Property | old value | new value
---|---|---
Version | `modtweaker-4.0.17` | `modtweaker-4.0.17.jar`
Release Type | `RELEASE` | `Release`
Author | `jaredlll08` | `Jaredlll08`



updated `morelibs`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `moreplates`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `mrtjpcore`

Property | old value | new value
---|---|---
Version | `MrTJPCore-1.12.2-2.1.3.35-universal.jar` | `MrTJPCore-1.12.2-2.1.4.43-universal.jar`
Release Type | `RELEASE` | `Release`



updated `mtlib`

Property | old value | new value
---|---|---
Version | `MTLib-3.0.6` | `MTLib-3.0.6.jar`
Release Type | `RELEASE` | `Release`
Author | `jaredlll08` | `Jaredlll08`



updated `nbtedit`

Property | old value | new value
---|---|---
Version | `0.7` | `NBTEdit-0.7.jar`
Release Type | `RELEASE` | `Release`



updated `opencomputers`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `openeye`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `openfm`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `orelib`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `p455w0rds-library`

Property | old value | new value
---|---|---
Version | `p455w0rdslib-1.12.2-2.1.44.jar` | `p455w0rdslib-1.12.2-2.2.151.jar`
Release Type | `RELEASE` | `Release`



updated `project-red-base`

Property | old value | new value
---|---|---
Version | `ProjectRed-1.12.2-4.9.1.92-Base.jar` | `ProjectRed-1.12.2-4.9.3.116-Base.jar`
Required Dependencies | `mrtjpcore`, `codechicken-lib-1-8`, `forge-multipart-cbe` | `forge-multipart-cbe`, `codechicken-lib-1-8`, `mrtjpcore`
Release Type | `RELEASE` | `Release`
Author | `Mr_TJP` | `covers1624, Mr_TJP`



updated `project-red-compat`

Property | old value | new value
---|---|---
Version | `ProjectRed-1.12.2-4.9.1.92-compat.jar` | `ProjectRed-1.12.2-4.9.3.116-compat.jar`
Release Type | `RELEASE` | `Release`
Author | `Mr_TJP` | `covers1624, Mr_TJP`



updated `project-red-fabrication`

Property | old value | new value
---|---|---
Version | `ProjectRed-1.12.2-4.9.1.92-fabrication.jar` | `ProjectRed-1.12.2-4.9.3.116-fabrication.jar`
Release Type | `RELEASE` | `Release`
Author | `Mr_TJP` | `covers1624, Mr_TJP`



updated `project-red-integration`

Property | old value | new value
---|---|---
Version | `ProjectRed-1.12.2-4.9.1.92-integration.jar` | `ProjectRed-1.12.2-4.9.3.116-integration.jar`
Release Type | `RELEASE` | `Release`
Author | `Mr_TJP` | `covers1624, Mr_TJP`



updated `project-red-lighting`

Property | old value | new value
---|---|---
Version | `ProjectRed-1.12.2-4.9.1.92-lighting.jar` | `ProjectRed-1.12.2-4.9.3.116-lighting.jar`
Release Type | `RELEASE` | `Release`
Author | `Mr_TJP` | `covers1624, Mr_TJP`



updated `railcraft`

Property | old value | new value
---|---|---
Version | `Railcraft 12.0.0 - MC 1.12.2` | `railcraft-12.0.0.jar`
Release Type | `RELEASE` | `Release`



updated `redstone-flux`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `sampler`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `shadowfacts-forgelin`

Property | old value | new value
---|---|---
Version | `Forgelin-1.8.2.jar` | `Forgelin-1.8.3.jar`
Release Type | `RELEASE` | `Release`



updated `spawner-imbuer`

Property | old value | new value
---|---|---
Version | `Spawner Imbuer 0.1` | `spawnerimbuer-0.1.jar`
Release Type | `RELEASE` | `Release`



updated `storage-drawers`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `swingthroughgrass`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `tesla-core-lib`

Property | old value | new value
---|---|---
Version | `Tesla Core Lib : 1.0.15.13` | `tesla-core-lib-1.12.2-1.0.15.jar`
Release Type | `BETA` | `Beta`



updated `thaumcraft`

Property | old value | new value
---|---|---
Release Type | `BETA` | `Beta`



updated `thaumic-computers`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `thaumic-jei`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `thermal-dynamics`

Property | old value | new value
---|---|---
Version | `ThermalDynamics-1.12.2-2.5.4.18-universal.jar` | `ThermalDynamics-1.12.2-2.5.5.21-universal.jar`
Required Dependencies | `thermal-foundation`, `codechicken-lib-1-8` | `codechicken-lib-1-8`, `thermal-foundation`
Release Type | `RELEASE` | `Release`



updated `thermal-foundation`

Property | old value | new value
---|---|---
Version | `ThermalFoundation-1.12.2-2.6.2.26-universal.jar` | `ThermalFoundation-1.12.2-2.6.3.27-universal.jar`
Required Dependencies | `cofhcore`, `cofh-world` | `cofh-core`, `cofh-world`
Release Type | `RELEASE` | `Release`



updated `tough-as-nails`

Property | old value | new value
---|---|---
Release Type | `BETA` | `Beta`
Author | `Glitchfiend, TDWP_FTW, TheAdubbz` | `Forstride, GlitchfiendMods, TheAdubbz`



updated `tough-expansion`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `tree-chopper`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



updated `wearable-backpacks`

Property | old value | new value
---|---|---
Version | ` Wearable Backpacks - 1.12.2 - 3.1.3` | `WearableBackpacks-1.12.2-3.1.3.jar`
Release Type | `RELEASE` | `Release`



updated `zetta-industries`

Property | old value | new value
---|---|---
Release Type | `RELEASE` | `Release`



### Removed Entries

removed `better-with-mods`

Property | old value | new value
---|---|---
ID | `better-with-mods` | 
Version | `BetterWithMods-1.12-2.3.20-1027.jar` | 
Provider | `CURSE` | 
Side | `BOTH` | 
Optional | `false` | 
Required Dependencies | `betterwithlib` | 
Release Type | `RELEASE` | 
Author | `BeetoGuy, BordListian, primetoxinz` | 



removed `betterwithlib`

Property | old value | new value
---|---|---
ID | `betterwithlib` | 
Version | `BetterWithLib-1.12-1.5.jar` | 
Provider | `CURSE` | 
Side | `BOTH` | 
Optional | `false` | 
Release Type | `RELEASE` | 
Author | `primetoxinz` | 



removed `cofhcore`

Property | old value | new value
---|---|---
ID | `cofhcore` | 
Version | `CoFHCore-1.12.2-4.6.2.25-universal.jar` | 
Provider | `CURSE` | 
Side | `BOTH` | 
Optional | `false` | 
Required Dependencies | `redstone-flux` | 
Release Type | `RELEASE` | 
Author | `KingLemming, TeamCoFH` | 



removed `thermalexpansion`

Property | old value | new value
---|---|---
ID | `thermalexpansion` | 
Version | `ThermalExpansion-1.12.2-5.5.3.41-universal.jar` | 
Provider | `CURSE` | 
Side | `BOTH` | 
Optional | `false` | 
Required Dependencies | `thermal-foundation`, `codechicken-lib-1-8` | 
Release Type | `RELEASE` | 
Author | `KingLemming, TeamCoFH` | 






