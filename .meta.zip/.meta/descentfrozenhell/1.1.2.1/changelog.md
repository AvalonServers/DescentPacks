# Descent Frozen Hell 1.1.2.1

Property | old value | new value
---|---|---
Pack Version | `1.1.2` | `1.1.2.1`

No change in entries




