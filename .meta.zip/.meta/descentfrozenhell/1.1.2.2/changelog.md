# Descent Frozen Hell 1.1.2.2

Property | old value | new value
---|---|---
Pack Version | `1.1.2.1` | `1.1.2.2`


## Entries

### Added Entries

added `matterlink`

Property | old value | new value
---|---|---
ID |  | `matterlink`
Version |  | `MatterLink-1.12.2-1.6.4.jar`
Provider |  | `CURSE`
Side |  | `SERVER`
Optional |  | `false`
Required Dependencies |  | `shadowfacts-forgelin`
Release Type |  | `Beta`
Author |  | `NikkyAI`






