# Descent Frozen Hell 1.1.4

Property | old value | new value
---|---|---
Pack Version | `1.1.3` | `1.1.4`


## Entries

### Updated Entries

updated `better-advancements`

Property | old value | new value
---|---|---
Author | `Way2muchnoise` | `way2muchnoise`



updated `just-enough-resources-jer`

Property | old value | new value
---|---|---
Author | `Way2muchnoise` | `way2muchnoise`



### Removed Entries

removed `p455w0rds-library`

Property | old value | new value
---|---|---
ID | `p455w0rds-library` | 
Version | `p455w0rdslib-1.12.2-2.2.151.jar` | 
Provider | `CURSE` | 
Side | `BOTH` | 
Optional | `false` | 
Release Type | `Release` | 
Author | `TheRealp455w0rd` | 



removed `tough-expansion`

Property | old value | new value
---|---|---
ID | `tough-expansion` | 
Version | `ToughExpansion-1.12-3.4.24.jar` | 
Provider | `CURSE` | 
Side | `BOTH` | 
Optional | `false` | 
Required Dependencies | `tough-as-nails`, `p455w0rds-library`, `redstone-flux` | 
Release Type | `Release` | 
Author | `TheRealp455w0rd` | 






