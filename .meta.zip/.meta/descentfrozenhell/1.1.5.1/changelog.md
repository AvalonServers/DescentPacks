# Descent Frozen Hell 1.1.5.1

Property | old value | new value
---|---|---
Pack Version | `1.1.4` | `1.1.5.1`


## Entries

### Updated Entries

updated `autoreglib`

Property | old value | new value
---|---|---
Version | `AutoRegLib-1.3-31.jar` | `AutoRegLib-1.3-32.jar`



updated `charset-audio`

Property | old value | new value
---|---|---
Version | `Charset-Audio-0.5.5.7.jar` | `Charset-Audio-0.5.6.0.jar`



updated `charset-immersion`

Property | old value | new value
---|---|---
Version | `Charset-Immersion-0.5.5.7.jar` | `Charset-Immersion-0.5.6.0.jar`



updated `charset-lib`

Property | old value | new value
---|---|---
Version | `Charset-Lib-0.5.5.7.jar` | `Charset-Lib-0.5.6.2.jar`



updated `charset-tablet`

Property | old value | new value
---|---|---
Version | `Charset-Tablet-0.5.5.7.jar` | `Charset-Tablet-0.5.6.0.jar`



updated `charset-tools`

Property | old value | new value
---|---|---
Version | `Charset-ToolsEngineering-0.5.5.2.jar` | `Charset-ToolsEngineering-0.5.6.0.jar`
Required Dependencies | `charset-lib` | 



updated `charset-tweaks`

Property | old value | new value
---|---|---
Version | `Charset-Tweaks-0.5.5.7.jar` | `Charset-Tweaks-0.5.6.2.jar`



updated `charsetpatches`

Property | old value | new value
---|---|---
Version | `CharsetPatches-0.1.6.jar` | `CharsetPatches-0.1.7.jar`



updated `gravestone-mod`

Property | old value | new value
---|---|---
Version | `gravestone-1.10.2.jar` | `gravestone-1.10.3.jar`
Release Type | `Beta` | `Alpha`



updated `industrial-foregoing`

Property | old value | new value
---|---|---
Version | `industrialforegoing-1.12.2-1.12.12-236.jar` | `industrialforegoing-1.12.2-1.12.13-237.jar`



updated `project-red-base`

Property | old value | new value
---|---|---
Version | `ProjectRed-1.12.2-4.9.3.116-Base.jar` | `ProjectRed-1.12.2-4.9.4.120-Base.jar`
Required Dependencies | `forge-multipart-cbe`, `codechicken-lib-1-8`, `mrtjpcore` | `mrtjpcore`, `codechicken-lib-1-8`, `forge-multipart-cbe`



updated `project-red-compat`

Property | old value | new value
---|---|---
Version | `ProjectRed-1.12.2-4.9.3.116-compat.jar` | `ProjectRed-1.12.2-4.9.4.120-compat.jar`
Required Dependencies | `project-red-base`, `mrtjpcore` | `mrtjpcore`, `project-red-base`



updated `project-red-fabrication`

Property | old value | new value
---|---|---
Version | `ProjectRed-1.12.2-4.9.3.116-fabrication.jar` | `ProjectRed-1.12.2-4.9.4.120-fabrication.jar`
Required Dependencies | `project-red-base`, `project-red-integration` | `project-red-integration`, `project-red-base`



updated `project-red-integration`

Property | old value | new value
---|---|---
Version | `ProjectRed-1.12.2-4.9.3.116-integration.jar` | `ProjectRed-1.12.2-4.9.4.120-integration.jar`



updated `project-red-lighting`

Property | old value | new value
---|---|---
Version | `ProjectRed-1.12.2-4.9.3.116-lighting.jar` | `ProjectRed-1.12.2-4.9.4.120-lighting.jar`






