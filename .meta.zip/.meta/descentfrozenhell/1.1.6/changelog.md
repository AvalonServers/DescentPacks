# Descent Frozen Hell 1.1.6

Property | old value | new value
---|---|---
Pack Version | `1.1.5.1` | `1.1.6`


## Entries

### Added Entries

added `integration-foregoing`

Property | old value | new value
---|---|---
ID |  | `integration-foregoing`
Version |  | `IntegrationForegoing-1.12.2-1.9.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `industrial-foregoing`
Release Type |  | `Release`
Author |  | `Buuz135, Jacky1356400`



added `project-red-world`

Property | old value | new value
---|---|---
ID |  | `project-red-world`
Version |  | `ProjectRed-1.12.2-4.9.4.120-world.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `project-red-base`
Release Type |  | `Release`
Author |  | `covers1624, Mr_TJP`



### Updated Entries

updated `applied-energistics-2`

Property | old value | new value
---|---|---
Version | `appliedenergistics2-rv6-stable-6.jar` | `appliedenergistics2-rv6-stable-7.jar`



updated `charsetpatches`

Property | old value | new value
---|---|---
Version | `CharsetPatches-0.1.7.jar` | `CharsetPatches-0.1.8.jar`






