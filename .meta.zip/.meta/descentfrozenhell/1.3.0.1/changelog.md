# Descent Frozen Hell 1.3.0.1

Property | old value | new value
---|---|---
Pack Version | `1.1.5.1` | `1.3.0.1`


## Entries

### Added Entries

added `alternating-flux`

Property | old value | new value
---|---|---
ID |  | `alternating-flux`
Version |  | `alternatingflux-0.12.2-2.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `immersive-engineering`
Release Type |  | `Release`
Author |  | `AntiBlueQuirk`



added `atomic-science`

Property | old value | new value
---|---|---
ID |  | `atomic-science`
Version |  | `Atomic-Science-1.12.2-3.2.0b3.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Release Type |  | `Alpha`
Author |  | `DarkGuardsman`



added `avaritia-1-10`

Property | old value | new value
---|---|---
ID |  | `avaritia-1-10`
Version |  | `Avaritia-1.12.2-3.3.0.33-universal.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `codechicken-lib-1-8`
Release Type |  | `Release`
Author |  | `brandon3055, covers1624, Morpheus1101, TheRealp455w0rd`



added `avaritia-complement`

Property | old value | new value
---|---|---
ID |  | `avaritia-complement`
Version |  | `Avaritia's Complement-1.12.2-1.2a.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `avaritia-1-10`
Release Type |  | `Release`
Author |  | `tfarecnim`



added `icbm-classic`

Property | old value | new value
---|---|---
ID |  | `icbm-classic`
Version |  | `ICBM-classic-1.12.2-3.3.0b65.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Release Type |  | `Alpha`
Author |  | `DarkGuardsman`



added `integration-foregoing`

Property | old value | new value
---|---|---
ID |  | `integration-foregoing`
Version |  | `IntegrationForegoing-1.12.2-1.9.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `industrial-foregoing`
Release Type |  | `Release`
Author |  | `Buuz135, Jacky1356400`



added `more-avaritia`

Property | old value | new value
---|---|---
ID |  | `more-avaritia`
Version |  | `moreavaritia-mc1.12.2-v3.2.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `avaritia-1-10`
Release Type |  | `Release`
Author |  | `TheUnderTaker11_`



added `project-red-world`

Property | old value | new value
---|---|---
ID |  | `project-red-world`
Version |  | `ProjectRed-1.12.2-4.9.4.120-world.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `project-red-base`
Release Type |  | `Release`
Author |  | `covers1624, Mr_TJP`



added `redstone-arsenal`

Property | old value | new value
---|---|---
ID |  | `redstone-arsenal`
Version |  | `RedstoneArsenal-1.12.2-2.6.3.18-universal.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `cofh-core`
Release Type |  | `Release`
Author |  | `KingLemming, TeamCoFH`



added `thaumic-augmentation`

Property | old value | new value
---|---|---
ID |  | `thaumic-augmentation`
Version |  | `ThaumicAugmentation-1.12.2-1.1.8.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `thaumcraft`
Release Type |  | `Release`
Author |  | `TheCodex6824`



added `thaumic-energistics`

Property | old value | new value
---|---|---
ID |  | `thaumic-energistics`
Version |  | `thaumicenergistics-2.2.3.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `applied-energistics-2`, `thaumcraft`
Release Type |  | `Release`
Author |  | `BrockWS, Nividica, TheRealp455w0rd`



added `thaumictinkerer`

Property | old value | new value
---|---|---
ID |  | `thaumictinkerer`
Version |  | `thaumictinkerer-1.12.2-5.0-41d79cc`
Provider |  | `DIRECT`
Side |  | `BOTH`
Optional |  | `false`
Url |  | `https://launcher.towerdevs.xyz/external/thaumictinkerer-1.12.2-5.0-41d79cc.jar`



### Updated Entries

updated `applied-energistics-2`

Property | old value | new value
---|---|---
Version | `appliedenergistics2-rv6-stable-6.jar` | `appliedenergistics2-rv6-stable-7.jar`



updated `bwm-suite`

Property | old value | new value
---|---|---
Version | `BetterWithMods-1.12-2.3.20-1035.jar` | `BetterWithMods-1.12-2.3.20-1037.jar`



updated `charset-audio`

Property | old value | new value
---|---|---
Version | `Charset-Audio-0.5.6.0.jar` | `Charset-Audio-0.5.6.3.jar`



updated `charset-block-carrying`

Property | old value | new value
---|---|---
Version | `Charset-TweakCarry-0.5.4.6.jar` | `Charset-TweakCarry-0.5.6.3.jar`



updated `charset-lib`

Property | old value | new value
---|---|---
Version | `Charset-Lib-0.5.6.2.jar` | `Charset-Lib-0.5.6.3.jar`



updated `charsetpatches`

Property | old value | new value
---|---|---
Version | `CharsetPatches-0.1.7.jar` | `CharsetPatches-0.1.8.jar`



updated `codechicken-lib-1-8`

Property | old value | new value
---|---|---
Version | `CodeChickenLib-1.12.2-3.2.2.353-universal.jar` | `CodeChickenLib-1.12.2-3.2.3.357-universal.jar`



updated `colytra`

Property | old value | new value
---|---|---
Version | `colytra-1.12.2-1.2.0.1.jar` | `colytra-1.12.2-1.2.0.3.jar`
Author | `theillusivec4` | `TheIllusiveC4`



updated `forge-multipart-cbe`

Property | old value | new value
---|---|---
Version | `ForgeMultipart-1.12.2-2.6.1.81-universal.jar` | `ForgeMultipart-1.12.2-2.6.2.83-universal.jar`



updated `immersive-engineering`

Property | old value | new value
---|---|---
Version | `ImmersiveEngineering-0.12-89.jar` | `ImmersiveEngineering-0.12-91.jar`



updated `journeymap`

Property | old value | new value
---|---|---
Version | `journeymap-1.12.2-5.5.5b9.jar` | `journeymap-1.12.2-5.5.5.jar`
Release Type | `Beta` | `Release`



updated `jei`

Property | old value | new value
---|---|---
Version | `jei_1.12.2-4.15.0.287.jar` | `jei_1.12.2-4.15.0.289.jar`



updated `laggoggles`

Property | old value | new value
---|---|---
Version | `LagGoggles-FAT-1.12.2-4.6.jar` | `LagGoggles-FAT-1.12.2-4.8.jar`



updated `storage-drawers`

Property | old value | new value
---|---|---
Version | `StorageDrawers-1.12.2-5.3.8.jar` | `StorageDrawers-1.12.2-5.4.0.jar`



updated `thaumic-computers`

Property | old value | new value
---|---|---
Version | `ThaumicComputers-MC1.12.2-0.4.4.jar` | `ThaumicComputers-MC1.12.2-0.5.1.jar`



updated `tough-as-nails`

Property | old value | new value
---|---|---
Author | `Forstride, GlitchfiendMods, TheAdubbz` | `Forstride, TheAdubbz`



### Removed Entries

removed `hardcore-darkness`

Property | old value | new value
---|---|---
ID | `hardcore-darkness` | 
Version | `HardcoreDarkness-MC1.12.2-2.0.jar` | 
Provider | `CURSE` | 
Side | `BOTH` | 
Optional | `false` | 
Release Type | `Release` | 
Author | `lumien231` | 






