# Descent Frozen Hell 1.3.0.2

Property | old value | new value
---|---|---
Pack Version | `1.3.0.1` | `1.3.0.2`


## Entries

### Updated Entries

updated `applied-energistics-2`

Property | old value | new value
---|---|---
Author | `akarso, AlgorithmX2, Cisien, FireBall1725, thatsIch` | `AlgorithmX2, FireBall1725, thatsIch, _ForgeUser16673090, _ForgeUser651564`



updated `avaritia-1-10`

Property | old value | new value
---|---|---
Author | `brandon3055, covers1624, Morpheus1101, TheRealp455w0rd` | `brandon3055, covers1624, Morpheus11011, TheRealp455w0rd`



updated `chameleon`

Property | old value | new value
---|---|---
Author | `jaquadro` | `Texelsaur`



updated `chisel`

Property | old value | new value
---|---|---
Author | `Drullkus, Minecreatr, tterrag1098` | `Drullkus, minecreatr, tterrag1098`



updated `codechicken-lib-1-8`

Property | old value | new value
---|---|---
Version | `CodeChickenLib-1.12.2-3.2.3.357-universal.jar` | `CodeChickenLib-1.12.2-3.2.3.358-universal.jar`
Author | `chicken_bones, covers1624` | `Chicken_Bones, covers1624`



updated `cofh-core`

Property | old value | new value
---|---|---
Author | `KingLemming, TeamCoFH` | `KingLemmingCoFH, TeamCoFH`



updated `cofh-world`

Property | old value | new value
---|---|---
Author | `KingLemming, skyboy026, TeamCoFH` | `KingLemmingCoFH, skyboy026, TeamCoFH`



updated `dynamic-lights`

Property | old value | new value
---|---|---
Author | `AtomicStryker` | `atomicstrykergrumpy`



updated `extracells2`

Property | old value | new value
---|---|---
Author | `Destroyer7128, DrummerMC, Pwnie2012` | `Destroyer7128, _ForgeUser16181044, _ForgeUser9582869`



updated `faster-ladder-climbing`

Property | old value | new value
---|---|---
Author | `MadDachshund` | `maddachshund`



updated `forge-multipart-cbe`

Property | old value | new value
---|---|---
Author | `covers1624, Mr_TJP` | `covers1624, MrTJP`



updated `gravestone-mod`

Property | old value | new value
---|---|---
Release Type | `Alpha` | `Release`
Author | `EuhDawson` | `henkelmax`



updated `immersive-engineering`

Property | old value | new value
---|---|---
Version | `ImmersiveEngineering-0.12-91.jar` | `ImmersiveEngineering-0.12-92.jar`



updated `immersive-petroleum`

Property | old value | new value
---|---|---
Author | `theFlaxbeard` | `Flaxbeard`



updated `immersive-tech`

Property | old value | new value
---|---|---
Author | `ferroo2000` | `FerroO2000`



updated `integration-foregoing`

Property | old value | new value
---|---|---
Author | `Buuz135, Jacky1356400` | `Buuz135, Jackyy`



updated `journeymap`

Property | old value | new value
---|---|---
Author | `mysticdrew, techbrew` | `Mysticdrew, techbrew`



updated `mrtjpcore`

Property | old value | new value
---|---|---
Author | `Mr_TJP` | `MrTJP`



updated `opencomputers`

Property | old value | new value
---|---|---
Author | `SangarWasTaken` | `Sangar_`



updated `openeye`

Property | old value | new value
---|---|---
Author | `OpenMods, other_boq` | `0x00716F62, OpenMods`



updated `project-red-base`

Property | old value | new value
---|---|---
Author | `covers1624, Mr_TJP` | `covers1624, MrTJP`



updated `project-red-compat`

Property | old value | new value
---|---|---
Author | `covers1624, Mr_TJP` | `covers1624, MrTJP`



updated `project-red-fabrication`

Property | old value | new value
---|---|---
Author | `covers1624, Mr_TJP` | `covers1624, MrTJP`



updated `project-red-integration`

Property | old value | new value
---|---|---
Author | `covers1624, Mr_TJP` | `covers1624, MrTJP`



updated `project-red-lighting`

Property | old value | new value
---|---|---
Author | `covers1624, Mr_TJP` | `covers1624, MrTJP`



updated `project-red-world`

Property | old value | new value
---|---|---
Author | `covers1624, Mr_TJP` | `covers1624, MrTJP`



updated `railcraft`

Property | old value | new value
---|---|---
Author | `CovertJaguar` | `Covert_Jaguar`



updated `redstone-arsenal`

Property | old value | new value
---|---|---
Author | `KingLemming, TeamCoFH` | `KingLemmingCoFH, TeamCoFH`



updated `redstone-flux`

Property | old value | new value
---|---|---
Author | `KingLemming, TeamCoFH` | `KingLemmingCoFH, TeamCoFH`



updated `sampler`

Property | old value | new value
---|---|---
Author | `Player` | `sfPlayer1`



updated `shadowfacts-forgelin`

Property | old value | new value
---|---|---
Version | `Forgelin-1.8.3.jar` | `Forgelin-1.8.4.jar`
Author | `shadowfactsmc` | `ShadowfactsDev`



updated `storage-drawers`

Property | old value | new value
---|---|---
Author | `jaquadro` | `Texelsaur`



updated `tesla-core-lib`

Property | old value | new value
---|---|---
Author | `Face_of_Cat` | `face_of_cat`



updated `thaumic-augmentation`

Property | old value | new value
---|---|---
Version | `ThaumicAugmentation-1.12.2-1.1.8.jar` | `ThaumicAugmentation-1.12.2-1.1.9.jar`



updated `thaumic-energistics`

Property | old value | new value
---|---|---
Author | `BrockWS, Nividica, TheRealp455w0rd` | `BrockWS, nividica, TheRealp455w0rd`



updated `thermal-dynamics`

Property | old value | new value
---|---|---
Author | `KingLemming, RWTema, TeamCoFH` | `KingLemmingCoFH, RWTema, TeamCoFH`



updated `thermal-expansion`

Property | old value | new value
---|---|---
Author | `KingLemming, TeamCoFH` | `KingLemmingCoFH, TeamCoFH`



updated `thermal-foundation`

Property | old value | new value
---|---|---
Author | `KingLemming, TeamCoFH` | `KingLemmingCoFH, TeamCoFH`



updated `tree-chopper`

Property | old value | new value
---|---|---
Author | `DuchLord` | `MrDuchy`



updated `wearable-backpacks`

Property | old value | new value
---|---|---
Version | `WearableBackpacks-1.12.2-3.1.3.jar` | `WearableBackpacks-1.12.2-3.1.4.jar`
Author | `asiekierka, InsomniaKitten, PuppetzMedia, user-6837585` | `asiekierka, HeckinChloe, user-6837585`



updated `zetta-industries`

Property | old value | new value
---|---|---
Author | `marcin212` | `marcin212a`






