# Descent Frozen Hell 1.3.0.3

Property | old value | new value
---|---|---
Pack Version | `1.3.0.2` | `1.3.0.3`


## Entries

### Updated Entries

updated `dynamic-surroundings`

Property | old value | new value
---|---|---
Version | `DynamicSurroundings-1.12.2-3.5.4.3.jar` | `DynamicSurroundings-1.12.2-3.5.5.0.jar`



updated `orelib`

Property | old value | new value
---|---|---
Version | `OreLib-1.12.2-3.5.2.2.jar` | `OreLib-1.12.2-3.5.2.3.jar`






