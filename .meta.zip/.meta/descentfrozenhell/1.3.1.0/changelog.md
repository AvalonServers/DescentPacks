# Descent Frozen Hell 1.3.1.0

Property | old value | new value
---|---|---
Pack Version | `1.3.0.3` | `1.3.1.0`


## Entries

### Added Entries

added `architecturecraft-tridev`

Property | old value | new value
---|---|---
ID |  | `architecturecraft-tridev`
Version |  | `architecturecraft-1.12-3.98.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Release Type |  | `Release`
Author |  | `darkevilmac`



added `opensecurity`

Property | old value | new value
---|---|---
ID |  | `opensecurity`
Version |  | `OpenSecurity-1.12.2-1.0-39.jar`
Provider |  | `CURSE`
Side |  | `BOTH`
Optional |  | `false`
Required Dependencies |  | `opencomputers`
Release Type |  | `Release`
Author |  | `ben_mkiv, MichiyoRavencroft`



### Updated Entries

updated `chisel`

Property | old value | new value
---|---|---
Version | `Chisel-MC1.12.2-0.2.1.35.jar` | `Chisel-MC1.12.2-1.0.0.42.jar`



updated `ctm`

Property | old value | new value
---|---|---
Version | `CTM-MC1.12.2-0.3.3.22.jar` | `CTM-MC1.12.2-1.0.0.29.jar`
Release Type | `Beta` | `Release`



updated `extracells2`

Property | old value | new value
---|---|---
Version | `ExtraCells-1.12.2-2.6.2a.jar` | `ExtraCells-1.12.2-2.6.3.jar`



updated `foamfix-for-minecraft`

Property | old value | new value
---|---|---
Version | `foamfix-0.10.5-1.12.2.jar` | `foamfix-0.10.8-1.12.2.jar`



updated `inventory-tweaks`

Property | old value | new value
---|---|---
Side | `CLIENT` | `BOTH`



updated `jei`

Property | old value | new value
---|---|---
Version | `jei_1.12.2-4.15.0.289.jar` | `jei_1.12.2-4.15.0.291.jar`



updated `thaumic-augmentation`

Property | old value | new value
---|---|---
Version | `ThaumicAugmentation-1.12.2-1.1.9.jar` | `ThaumicAugmentation-1.12.2-1.1.10.jar`






